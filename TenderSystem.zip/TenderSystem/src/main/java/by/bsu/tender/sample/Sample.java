package by.bsu.tender.sample;

public class Sample extends Object {

	private String name;
	//private String secondname;
	
	public Sample(String name) {
		super();
		this.name = name;
		//this.secondname = secondname;
	}

}
