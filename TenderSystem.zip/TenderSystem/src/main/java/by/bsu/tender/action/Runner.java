package by.bsu.tender.action;

import java.util.Date;

import by.bsu.tender.Tender;
import by.bsu.tender.exception.TenderLogicException;
import by.bsu.tender.database.BTree;
import java.text.ParseException;
import org.apache.log4j.Logger;

public class Runner {

	public static void main(String[] args) {
		
		//Logger log = Logger.getLogger("scientificwork");
		String databaseFile = "Math.tcb";
		int number = 1;
		
		//Tender tender = new Tender("Sciense", "Minsk", 1, "Math", "First tender", 100, "19 Nov 2014");
		try {
			Tender tender1 = new Tender("Sciense", "Minsk", 1, "Math", "First tender", 100, "April 9, 2012");
			BTree.addTender(databaseFile, tender1);
			BTree.findTender(databaseFile, number);
		} catch (TenderLogicException | ParseException e) {
			//log.error("Tender object exception. Error: " + e);
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
