package by.bsu.tender;

import java.text.DateFormat;
import java.text.ParseException;
import java.util.*;
import by.bsu.tender.exception.TenderLogicException;
import java.io.Serializable;
import java.io.*;

public class Tender implements Serializable{

	private String nameTender;
	private String region;
	private int applicationNumber;
	private String subsection;
	private String description;
	private int price;
	private String begin;
	//добавить поля имя/название того, кто добавил тендер и конец тендера 
	
	public Tender() {}
	public Tender(String name, String nameRegion, int application, String subsection, String description, int price, String begining) throws TenderLogicException, ParseException {
		nameTender = name;
		region = nameRegion;
		applicationNumber = application;
		this.subsection = subsection;
		this.description = description;
		this.price = price;
		//DateFormat date = DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.US);
		//try{
			begin = begining;
		//} catch(ParseException e){
			//throw e;
		//}
	}
	
	public String getNameTender(){
		return nameTender;
	}
	
	public String getNameRegion(){
		return region;
	}
	
	public int getApplicationNumber(){
		return applicationNumber;
	}
	
	public String getSubsection(){
		return subsection;
	}
	
	public String getDescription(){
		return description;
	}
	
	public int getPrice(){
		return price;
	}
	
	public String getDateBegin(){
		return begin;
	}
	
	public void setNameTender(String name) throws TenderLogicException {
		if (name.length() == 0)
			throw new TenderLogicException("Name of tender is empty.");
		nameTender = name;
	}
	
	public void setNameRegion(String nameRegion) throws TenderLogicException {
		if (nameRegion.length() == 0)
			throw new TenderLogicException("Name of region is empty.");
		region = nameRegion;
	}
	
	public void setApplicationNumber(int applicationNumber) throws TenderLogicException {
		if (applicationNumber <= 0)
			throw new TenderLogicException("Application number of tender is empty.");
		this.applicationNumber = applicationNumber;
	}
	
	public void setSubsection(String subsection) throws TenderLogicException {
		if (subsection.length() == 0)
			throw new TenderLogicException("Name of subsection is empty.");
		this.subsection = subsection;
	}
	
	public void setDescription(String description) throws TenderLogicException {
		if (description.length() == 0)
			throw new TenderLogicException("Description of tender is empty.");
		this.description = description;
	}
	
	public void setPrice(int price) throws TenderLogicException {
		if (price <= 0)
			throw new TenderLogicException("Price of tender is incorrect.");
		this.price = price;
	}
	
	/*public void setDateBegin(String begining) throws ParseException {
		DateFormat date = DateFormat.getDateInstance(DateFormat.LONG, new Locale("BY"));
		try{
			begin = date.parse(begining);
		} catch(ParseException e){
			throw e;
		}
	}*/
	
	@Override
	public String toString(){
		return "" + this.getNameTender() + " " + this.getNameRegion() + " " + this.getApplicationNumber() + " " + this.getSubsection() + " " + this.getDescription() + " " + this.getPrice() + " " + this.getDateBegin();
	}
	
	/*public static Tender deserialize(byte[] data) throws InvalidObjectException {
	    try {
	    	ByteArrayInputStream in = new ByteArrayInputStream(data);
	    	ObjectInputStream is = new ObjectInputStream(in);
	    	Tender tender = (Tender) is.readObject();
	    	return tender;
	    } catch(ClassNotFoundException ce) {
	    	System.out.println("Class not exist." + ce);
	    } catch(InvalidClassException ioe) {
	    	System.out.println("Versions of class are different." + ioe);
	    } catch(IOException ioe) {
	    	System.out.println("Ordinary error." + ioe);
	    }
	    throw new InvalidObjectException("Object not restore.");
	}*/
}
